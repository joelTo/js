
## Préparation

Dans un shell

```
>npm init
>npm install json-server --save-dev
>npm install serve --save-dev
```

## Lancement

### Lancement api json

Dans un premier shell

```
>npm run api
```

### Lancement de l'application

Dans un second shell

```
>npm start
```
